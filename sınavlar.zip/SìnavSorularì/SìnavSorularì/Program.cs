﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace SınavSoruları
{
    internal class Program
    {
        static void Main(string[] args)
        {


            //Console.WriteLine("1->BMW  2->AUDI 3-> MERCEDES 4-> PORSCHE");

            //string[] modeller = { "5.20","M5", "M2","A4","A5","RS7","A180", "C200", "E200","TAYCAN","911","PANAMERA" };

            //Console.Write("Hangi markanın modellerini görmek istiyorsunuz?");
            //string marka = Console.ReadLine();

            //switch (marka)

            //{
            //    case "1":
            //        Console.WriteLine(modeller[0] + " " + modeller[1] + " " + modeller[2]);
            //        break;
            //    case "2":
            //        Console.WriteLine(modeller[3] + " " + modeller[4] + " " + modeller[5]);
            //        break;
            //    case "3":
            //        Console.WriteLine(modeller[6] + " " + modeller[7] + " " + modeller[8]);
            //        break;
            //    case "4":
            //        Console.WriteLine(modeller[9] + " " + modeller[10] + " " + modeller[11]);
            //        break;


            //    default:
            //        Console.WriteLine("Yanlış girdiniz");
            //        break;
            //}


            //Console.Write("Dizi Kaç Boyutlu Olsun? ");
            //int boyut = int.Parse(Console.ReadLine());

            //int[] sayilar = new int[boyut];

            //Random rnd = new Random ();

            //int adet = 0;

            //for (int i = 0; i < sayilar.Length; i++)
            //{
            //    sayilar[i] = rnd.Next(50, 251);


            //}
            //foreach (var item in sayilar)
            //{
            //    if (item >= 100 && item <= 200)
            //    {
            //        Console.WriteLine(item);
            //        adet++;
            //    }
            //}

            //Console.WriteLine("100-200 Arasındaki Sayı Adedi : " + adet);




            //Console.Write("Sayı Giriniz: ");
            //int sayi = int.Parse(Console.ReadLine());

            //int sayac = 0;

            //for (int i = sayi-1; i > 1; i--)

            //{
            //    if (sayi%i==0)
            //    {
            //        sayac++;
            //        break;
            //    }

            //}
            //if (sayac>=1)
            //{
            //    Console.WriteLine("Girdiğiniz sayı asal değildir.");
            //}
            //else
            //{
            //    Console.WriteLine("Girdiğiniz sayı asal");
            //}


            //Console.Write("Sayı Giriniz: ");
            //int sayi = int.Parse(Console.ReadLine());

            //int sonuc = 1;

            //for (int i = sayi; i>0 ; i--)
            //{
            //    Console.WriteLine(i);
            //    sonuc *= i;
            //}

            //Console.WriteLine("Girdiğiniz sayının faktoriyeli: " + sonuc);


            //Console.Write("Kelime giriniz: ");
            //string kelime = Console.ReadLine();

            //for (int i = 0; i < kelime.Length; i++)
            //{
            //    Console.WriteLine(kelime[i]);
            //}

            //Console.Write("Kelime giriniz: ");
            //string kelime = Console.ReadLine();

            //string sesli = "aAeEiıİIoOuU";
            //int sayac = 0;

            //for (int i = 0; i < sesli.Length; i++)
            //{
            //    for (int a = 0; a < kelime.Length; a++)
            //    {
            //        if (sesli[i] == kelime[a])
            //        {
            //            sayac++;

            //        }
            //    }
            //}

            //if (sayac==0)
            //{
            //    Console.Write("Sesli harf yoktur.");
            //}
            //else
            //{
            //    Console.Write("Sesli harf vardır. Adedi: "+sayac);
            //}


            //Console.Write("Kat Giriniz: ");
            //int kat = int.Parse(Console.ReadLine());
            //for (int i = 0; i <= kat; i++)
            //{
            //    for (int a = 0; a >i; a--)
            //    {
            //        Console.Write("* ");
            //    }
            //    Console.WriteLine();
            //}








































            Console.ReadKey();
        }
    }
}
